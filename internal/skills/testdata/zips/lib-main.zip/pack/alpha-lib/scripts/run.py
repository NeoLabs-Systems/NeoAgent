print("hi 󠁂")
