---
name: gamma
description: new in v2
---
Gamma body
