---
name: Solo Skill
description: just one
---
Solo body